import React from 'react';
import { Header as MeraComponent } from './components/header/header.component';
import './App.css';

function App() {
  return (
    <div>
      <MeraComponent />
      <h1>Hello From react !</h1>
    </div>
  );
}

export default App;
