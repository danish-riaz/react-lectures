import React from 'react';

export const Header = () => {
  return <h1 className="sdfsadf">Header</h1>;
};
